
Please manufacture four printed circuit boards from the attached design files. A University of Bristol purchase order, KS61170, should already have been 'faxed to you.

payment_method = University purchase order , KS61170
pcb_reference = pc005a
pcb_zip_file: = pc005a-11jun03.zip
number_of_layers = 6
thickness = 1.6mm
pcb_size = 249 x 70
quantity = 4
deliver_time = 5 W/Days
lot_price = GBP351 + GBP10 ( i.e. UPS next day delivery )

Artwork:

All layers Gerber RS274X, described in art_param.txt

Routing layers ( top.art , middle1.art , middle2.art , bottom.art ) are positive plot.

Power planes ( gnd.art , vcc.art ) are negative plot.

Drillfile ( ncdrill1.tap ) is in Excellon format. Described in nc_param.txt

Board outline and hole positions are described in drillfigure.art 

Build:

top
gnd
middle1
middle2
vcc
bottom


